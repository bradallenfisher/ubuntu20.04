<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


define('WP_CACHE', true);

define('FS_METHOD','direct');

// BEGIN iThemes Security - Do not modify or remove this line
// iThemes Security Config Details: 2
define( 'DISALLOW_FILE_EDIT', true ); // Disable File Editor - Security > Settings > WordPress Tweaks > File Editor
// END iThemes Security - Do not modify or remove this line

// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', 'fws_lgwp' );


/** MySQL database username */

define( 'DB_USER', 'fws_admin' );


/** MySQL database password */

define( 'DB_PASSWORD', '4^!ga#@&JEYG4n7jvwk!!*9XnmjkAs6H6jkJXZs5J' );


/** MySQL hostname */

define( 'DB_HOST', 'localhost' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '$/0:TCl,U;<H5p3S&gfIzD DcD$-i9q*Ts&a1<MdY6.tOBVk1Y,~)7@l~{Vs&{P&' );

define( 'SECURE_AUTH_KEY',  'fX*ervz{W/+@o9/$I|mPr~#2}I/wpUx<xTT|J*&N]+|fk[LUJqO&,vn?!1Txd 9V' );

define( 'LOGGED_IN_KEY',    'W6>pzXQDzn.^/`Lh !|@Cb-Ef<][ewGW<#?FCA6~1~z%+u9V1W7alC8@ 8?64j0K' );

define( 'NONCE_KEY',        '8/{gTL)@o_C`RO#%>K@OS|4re%5,|0|D+q%|TA%5z&Hh45KC `<R20KFNGTRO%`@' );

define( 'AUTH_SALT',        '`S11}=5Qs1jw}i6sh_Pr9^=NI+0jttvO9x5pREiWHRHYak.dhW`lA-5PRHbA|-j7' );

define( 'SECURE_AUTH_SALT', 'S,;zEJ).s3.[b~v~fZ;^biemX|VLWbGj06yah.Z/HoCbgBi$~}BI,]P|~3)h=PCm' );

define( 'LOGGED_IN_SALT',   '[Qd|nr e^K;1v*7=cstC0gOUP(2{B-$3o6#n&QdKITWl~>1RoLa|wJru}-pDmlBQ' );

define( 'NONCE_SALT',       '}MY~aj+H$Z]74>U*l5E5T@.}FGOc27l)$M<eHsGPq86CXWwf0)WshZ$#C}7.;rnM' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

